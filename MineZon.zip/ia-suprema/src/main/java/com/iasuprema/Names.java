package com.iasuprema;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;

/** Utilitarios para converter nomes dados pela IA em blocos/itens e comparar ids. */
public final class Names {
    private Names() {}

    public static String id(Block b) {
        ResourceLocation k = ForgeRegistries.BLOCKS.getKey(b);
        return k == null ? "?" : k.toString();
    }

    public static String id(Item i) {
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(i);
        return k == null ? "?" : k.toString();
    }

    public static String id(EntityType<?> t) {
        ResourceLocation k = ForgeRegistries.ENTITIES.getKey(t);
        return k == null ? "?" : k.toString();
    }

    /** Vazio casa com tudo. Com ":" exige id exato; sem ":" aceita o nome ou parte dele (ex.: "log" casa oak_log). */
    public static boolean matches(String id, String spec) {
        if (spec == null || spec.isBlank()) return true;
        String s = spec.toLowerCase(Locale.ROOT).trim();
        if (s.contains(":")) return id.equals(s);
        String path = id.substring(id.indexOf(':') + 1);
        return path.equals(s) || path.contains(s);
    }

    private static ResourceLocation parse(String spec) {
        if (spec == null) return null;
        String s = spec.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) return null;
        return s.contains(":") ? ResourceLocation.tryParse(s) : ResourceLocation.tryParse("minecraft:" + s);
    }

    /** Bloco exato pelo nome, ou null se nao existir. */
    public static Block block(String spec) {
        ResourceLocation rl = parse(spec);
        if (rl == null || !ForgeRegistries.BLOCKS.containsKey(rl)) return null;
        return ForgeRegistries.BLOCKS.getValue(rl);
    }

    /** Bloco com estado, ex.: "minecraft:oak_stairs[facing=north,half=bottom]". Null se invalido. */
    public static net.minecraft.world.level.block.state.BlockState state(String spec) {
        if (spec == null) return null;
        String s = spec.trim();
        if (s.isEmpty()) return null;
        if (!s.contains(":")) s = "minecraft:" + s;
        try {
            net.minecraft.commands.arguments.blocks.BlockStateParser p =
                    new net.minecraft.commands.arguments.blocks.BlockStateParser(
                            new com.mojang.brigadier.StringReader(s), false).parse(false);
            return p.getState();
        } catch (Exception e) {
            return null;
        }
    }

    /** Item exato pelo nome, ou null se nao existir. */
    public static Item item(String spec) {
        ResourceLocation rl = parse(spec);
        if (rl == null || !ForgeRegistries.ITEMS.containsKey(rl)) return null;
        return ForgeRegistries.ITEMS.getValue(rl);
    }
}
