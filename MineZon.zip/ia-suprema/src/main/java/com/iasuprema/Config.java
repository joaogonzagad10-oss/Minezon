package com.iasuprema;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<String> PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> BASE_URL;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> PREFIX;
    public static final ForgeConfigSpec.IntValue MAX_TOKENS;
    public static final ForgeConfigSpec.IntValue TIMEOUT_SECONDS;
    public static final ForgeConfigSpec.IntValue MAX_REPLANS;
    public static final ForgeConfigSpec.IntValue SEARCH_RADIUS;
    public static final ForgeConfigSpec.IntValue MAX_BLOCKS_PER_FILL;
    public static final ForgeConfigSpec.BooleanValue CREATIVE_MODE;
    public static final ForgeConfigSpec.BooleanValue ALLOW_TELEPORT_UNSTUCK;
    public static final ForgeConfigSpec.IntValue FOLLOWUP_SECONDS;
    public static final ForgeConfigSpec.BooleanValue ALLOW_COMMANDS;
    public static final ForgeConfigSpec.BooleanValue COMMANDS_BYPASS_OP_ON_SERVERS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("ia");
        PROVIDER = b.comment("Provedor de IA: \"anthropic\" ou \"openai\" (qualquer API compativel com OpenAI: Gemini, Groq, OpenRouter, etc.)")
                .define("provider", "anthropic");
        API_KEY = b.comment("Sua chave de API. Fica so neste arquivo, nao compartilhe.")
                .define("apiKey", "");
        BASE_URL = b.comment("URL base da API. Vazio = padrao do provedor. Exemplo Gemini: https://generativelanguage.googleapis.com/v1beta/openai")
                .define("baseUrl", "");
        MODEL = b.comment("Nome do modelo, exatamente como o provedor chama.")
                .define("model", "claude-sonnet-5-5");
        PREFIX = b.comment("Palavra que chama a IA no chat. Ex.: \"ia constroi uma casa\"")
                .define("prefix", "ia");
        FOLLOWUP_SECONDS = b.comment("Depois que a IA fala, quantos segundos suas mensagens SEM o prefixo ainda sao entendidas como resposta pra ela. 0 = sempre exigir o prefixo (use 0 em servidor com muita gente).")
                .defineInRange("followUpSeconds", 90, 0, 600);
        MAX_TOKENS = b.defineInRange("maxTokens", 3000, 256, 8192);
        TIMEOUT_SECONDS = b.defineInRange("timeoutSeconds", 60, 10, 300);
        MAX_REPLANS = b.comment("Quantas vezes a IA pode replanejar sozinha depois de terminar as acoes")
                .defineInRange("maxReplans", 8, 0, 50);
        b.pop();

        b.push("jogo");
        SEARCH_RADIUS = b.comment("Raio (blocos) para procurar blocos/itens/mobs")
                .defineInRange("searchRadius", 24, 4, 64);
        MAX_BLOCKS_PER_FILL = b.comment("Limite de blocos por comando de construcao")
                .defineInRange("maxBlocksPerFill", 4096, 1, 65536);
        CREATIVE_MODE = b.comment("true = construir sem gastar materiais do inventario")
                .define("creativeMode", false);
        ALLOW_TELEPORT_UNSTUCK = b.comment("true = o companheiro se teletransporta pra perto do alvo quando fica preso")
                .define("allowTeleportWhenStuck", true);
        ALLOW_COMMANDS = b.comment("true = a IA pode executar comandos do Minecraft (/summon, /time, /give...) com as permissoes do jogador. Quem nao e operador nao consegue.")
                .define("allowCommands", true);
        COMMANDS_BYPASS_OP_ON_SERVERS = b.comment("false (recomendado) = em servidor multiplayer so operadores usam comandos pela IA. No singleplayer sempre funciona, mesmo sem ser OP. true = libera para todos (PERIGOSO em servidor publico).")
                .define("commandsBypassOpOnServers", false);
        b.pop();

        SPEC = b.build();
    }
}
