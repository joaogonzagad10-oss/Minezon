package com.iasuprema.ai;

import com.iasuprema.Config;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Liga o chat, a API de IA e as tarefas do companheiro. */
public final class AiBrain {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "iasuprema-http");
        t.setDaemon(true);
        return t;
    });

    private static final int MAX_HISTORY = 16;

    private AiBrain() {}

    /** Mantido para compatibilidade com a entidade; a busca e feita por varredura. */
    public static void register(UUID owner, UUID companion) {}

    public static CompanionEntity find(MinecraftServer server, UUID owner) {
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof CompanionEntity c && owner.equals(c.getOwnerId()) && c.isAlive()) return c;
            }
        }
        return null;
    }

    /** Uma frase do jogador no chat. Chamado no thread do servidor. */
    public static void onPlayerMessage(CompanionEntity c, String text) {
        if (c.thinking) {
            c.say("Peraí, ainda estou pensando na ordem anterior...");
            return;
        }
        // Nao cancela o que esta rodando: uma frase so de conversa ("valeu", "era diamante mesmo") nao deve parar o trabalho.
        // Se a IA mandar novas acoes, elas substituem as antigas (setPlan).
        c.goal = text;
        c.replans = 0;
        request(c, "JOGADOR: " + text + "\n\n[CONTEXTO]\n" + c.snapshot());
    }

    /** Fila de tarefas esvaziou (ou uma falhou). Chamado no thread do servidor. */
    public static void onIdle(CompanionEntity c, boolean failed) {
        if (c.thinking) return;
        if (!c.goalActive) {
            if (failed && !c.report.isEmpty()) c.say(c.report.get(c.report.size() - 1));
            c.report.clear();
            return;
        }
        if (c.replans >= Config.MAX_REPLANS.get()) {
            c.say("Cheguei no limite de replanejamentos. Me diga o que fazer agora.");
            c.goalActive = false;
            c.report.clear();
            return;
        }
        c.replans++;
        StringBuilder sb = new StringBuilder("RELATORIO das acoes:\n");
        for (String r : c.report) sb.append("- ").append(r).append('\n');
        c.report.clear();
        sb.append("\n[CONTEXTO]\n").append(c.snapshot());
        request(c, sb.toString());
    }

    private static void request(CompanionEntity c, String userContent) {
        MinecraftServer server = c.getServer();
        if (server == null) return;
        c.thinking = true;

        c.history.addLast("user\u0000" + userContent);
        while (c.history.size() > MAX_HISTORY) c.history.removeFirst();
        while (!c.history.isEmpty() && !c.history.peekFirst().startsWith("user\u0000")) c.history.removeFirst();

        List<String[]> msgs = new ArrayList<>();
        for (String h : c.history) {
            int i = h.indexOf('\u0000');
            msgs.add(new String[]{h.substring(0, i), h.substring(i + 1)});
        }

        POOL.submit(() -> {
            String answer = null;
            String error = null;
            try {
                answer = AiClient.ask(Prompt.SYSTEM, msgs);
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String ans = answer;
            final String err = error;
            server.execute(() -> deliver(c, ans, err));
        });
    }

    private static void deliver(CompanionEntity c, String answer, String error) {
        c.thinking = false;
        if (!c.isAlive()) return;

        if (error != null) {
            c.history.pollLast(); // mantem a alternancia user/assistant
            c.goalActive = false;
            c.say("Nao consegui falar com a IA: " + error);
            return;
        }

        ActionParser.Plan plan;
        try {
            plan = ActionParser.parse(answer);
        } catch (Exception e) {
            c.history.pollLast();
            c.goalActive = false;
            c.say("A resposta da IA veio num formato que eu nao entendi (" + e.getMessage() + ").");
            return;
        }

        c.history.addLast("assistant\u0000" + answer);
        if (!plan.say.isBlank()) c.say(plan.say);
        for (String w : plan.warnings) c.report.add("aviso: " + w);

        if (plan.tasks.isEmpty()) {
            // so conversa: nao mexe no que ja esta rodando
            if (c.current == null && c.queue.isEmpty()) {
                c.goalActive = false;
                c.report.clear();
            }
            return;
        }
        c.goalActive = plan.cont;
        c.report.clear();
        c.setPlan(plan.tasks);
    }
}
