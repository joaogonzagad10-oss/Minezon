package com.iasuprema.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.iasuprema.Config;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

/** Cliente HTTP para Anthropic e para APIs compativeis com OpenAI. Roda fora do thread do servidor. */
public final class AiClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    private AiClient() {}

    /** msgs: pares {role, content}, comecando por "user" e alternando. Devolve o texto da resposta. */
    public static String ask(String system, List<String[]> msgs) throws Exception {
        String key = Config.API_KEY.get().trim();
        if (key.isEmpty()) {
            throw new IllegalStateException("Nenhuma chave de API configurada. Edite config/iasuprema-common.toml (campo apiKey).");
        }
        String provider = Config.PROVIDER.get().trim().toLowerCase();
        String base = Config.BASE_URL.get().trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);

        JsonArray arr = new JsonArray();
        JsonObject body = new JsonObject();
        body.addProperty("model", Config.MODEL.get());
        body.addProperty("max_tokens", Config.MAX_TOKENS.get());

        HttpRequest.Builder rb;
        if (provider.equals("anthropic")) {
            String url = (base.isEmpty() ? "https://api.anthropic.com" : base) + "/v1/messages";
            body.addProperty("system", system);
            for (String[] m : msgs) arr.add(msg(m[0], m[1]));
            body.add("messages", arr);
            rb = HttpRequest.newBuilder(URI.create(url))
                    .header("x-api-key", key)
                    .header("anthropic-version", "2023-06-01");
        } else {
            String url = (base.isEmpty() ? "https://api.openai.com/v1" : base) + "/chat/completions";
            arr.add(msg("system", system));
            for (String[] m : msgs) arr.add(msg(m[0], m[1]));
            body.add("messages", arr);
            rb = HttpRequest.newBuilder(URI.create(url))
                    .header("Authorization", "Bearer " + key);
        }

        HttpRequest req = rb
                .header("content-type", "application/json")
                .timeout(Duration.ofSeconds(Config.TIMEOUT_SECONDS.get()))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() / 100 != 2) {
            String b = resp.body();
            if (b.length() > 300) b = b.substring(0, 300);
            throw new IllegalStateException("A API respondeu HTTP " + resp.statusCode() + ": " + b);
        }

        JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
        if (provider.equals("anthropic")) {
            StringBuilder sb = new StringBuilder();
            for (JsonElement e : json.getAsJsonArray("content")) {
                JsonObject o = e.getAsJsonObject();
                if (o.has("text")) sb.append(o.get("text").getAsString());
            }
            return sb.toString();
        }
        return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString();
    }

    private static JsonObject msg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }
}
