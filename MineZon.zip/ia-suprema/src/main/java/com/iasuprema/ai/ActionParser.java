package com.iasuprema.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.iasuprema.task.BuildTasks;
import com.iasuprema.task.CombatTasks;
import com.iasuprema.task.InvTasks;
import com.iasuprema.task.MineTasks;
import com.iasuprema.task.MoveTasks;
import com.iasuprema.task.Task;

import java.util.ArrayList;
import java.util.List;

/** Converte o JSON devolvido pela IA em tarefas. */
public final class ActionParser {
    private ActionParser() {}

    public static final class Plan {
        public String say = "";
        public boolean cont = false;
        public final List<Task> tasks = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
    }

    public static Plan parse(String raw) throws Exception {
        int a = raw.indexOf('{');
        int b = raw.lastIndexOf('}');
        if (a < 0 || b <= a) throw new IllegalArgumentException("a IA nao devolveu JSON");
        JsonObject root = JsonParser.parseString(raw.substring(a, b + 1)).getAsJsonObject();

        Plan plan = new Plan();
        plan.say = str(root, "say", "");
        plan.cont = root.has("continue") && root.get("continue").isJsonPrimitive() && root.get("continue").getAsBoolean();

        if (root.has("actions") && root.get("actions").isJsonArray()) {
            JsonArray arr = root.getAsJsonArray("actions");
            int n = 0;
            for (JsonElement e : arr) {
                if (!e.isJsonObject()) continue;
                if (n++ >= 40) {
                    plan.warnings.add("acoes demais, ignorei o excesso");
                    break;
                }
                try {
                    Task t = toTask(e.getAsJsonObject());
                    if (t != null) plan.tasks.add(t);
                } catch (Exception ex) {
                    plan.warnings.add("acao invalida ignorada: " + e + " (" + ex.getMessage() + ")");
                }
            }
        }
        return plan;
    }

    private static Task toTask(JsonObject o) {
        String type = str(o, "type", "").toLowerCase();
        switch (type) {
            case "goto":
                return new MoveTasks.GoTo(num(o, "x"), num(o, "y"), num(o, "z"));
            case "come":
                return new MoveTasks.ComeToMe();
            case "follow":
                return new MoveTasks.Follow();
            case "wait":
                return new MoveTasks.Wait(o.has("seconds") ? num(o, "seconds") : 3);
            case "stop":
                return new MoveTasks.Stop();
            case "say":
                return new MoveTasks.Say(str(o, "text", ""));
            case "mine":
                return new MineTasks.Mine(str(o, "block", ""), (int) (o.has("count") ? num(o, "count") : 1));
            case "collect":
                return new MineTasks.Collect(str(o, "item", ""));
            case "fill":
                return new BuildTasks.Fill(str(o, "block", ""),
                        (int) Math.floor(num(o, "x1")), (int) Math.floor(num(o, "y1")), (int) Math.floor(num(o, "z1")),
                        (int) Math.floor(num(o, "x2")), (int) Math.floor(num(o, "y2")), (int) Math.floor(num(o, "z2")),
                        str(o, "mode", "solid"),
                        o.has("replace") && o.get("replace").getAsBoolean());
            case "craft":
                return new InvTasks.Craft(str(o, "item", ""), (int) (o.has("count") ? num(o, "count") : 1));
            case "give":
                return new InvTasks.GiveToPlayer(str(o, "item", ""), (int) (o.has("count") ? num(o, "count") : -1));
            case "command":
                return new com.iasuprema.task.CmdTask(str(o, "command", ""),
                        o.has("confirmed") && o.get("confirmed").isJsonPrimitive() && o.get("confirmed").getAsBoolean());
            case "equip":
                return new InvTasks.EquipBest();
            case "attack":
                return new CombatTasks.Attack(str(o, "target", "hostile"), (int) (o.has("count") ? num(o, "count") : 1));
            default:
                throw new IllegalArgumentException("tipo desconhecido '" + type + "'");
        }
    }

    private static String str(JsonObject o, String k, String def) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : def;
    }

    private static double num(JsonObject o, String k) {
        if (!o.has(k)) throw new IllegalArgumentException("falta o campo '" + k + "'");
        return o.get(k).getAsDouble();
    }
}
