package com.iasuprema.task;

import com.iasuprema.Config;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.server.level.ServerPlayer;

/** Tarefas simples: falar, esperar, andar, seguir. */
public final class MoveTasks {
    private MoveTasks() {}

    public static class Say extends Task {
        private final String msg;

        public Say(String msg) {
            this.msg = msg;
        }

        @Override
        public String describe() {
            return "dizer";
        }

        @Override
        public State tick(CompanionEntity c) {
            c.say(msg);
            return done("falei");
        }
    }

    /** Encerra o objetivo atual (a IA nao replaneja depois). */
    public static class Finish extends Task {
        private final String msg;

        public Finish(String msg) {
            this.msg = msg;
        }

        @Override
        public String describe() {
            return "finalizar";
        }

        @Override
        public State tick(CompanionEntity c) {
            if (msg != null && !msg.isBlank()) c.say(msg);
            c.goalActive = false;
            return done("objetivo encerrado");
        }
    }

    public static class Wait extends Task {
        private final int ticks;

        public Wait(double seconds) {
            this.ticks = (int) Math.max(1, Math.min(seconds, 120) * 20);
        }

        @Override
        public String describe() {
            return "esperar " + (ticks / 20) + "s";
        }

        @Override
        public State tick(CompanionEntity c) {
            return age >= ticks ? done("esperei") : State.RUNNING;
        }
    }

    public static class Stop extends Task {
        @Override
        public String describe() {
            return "parar";
        }

        @Override
        public State tick(CompanionEntity c) {
            c.getNavigation().stop();
            return done("parado");
        }
    }

    public static class GoTo extends Task {
        private final double x, y, z;

        public GoTo(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        @Override
        public String describe() {
            return "ir para " + (int) x + " " + (int) y + " " + (int) z;
        }

        @Override
        public State tick(CompanionEntity c) {
            if (moveToward(c, x + 0.5D, y, z + 0.5D, 1.8D)) return done("cheguei");
            if (age > 20 * 90) return fail("nao consegui chegar (muito longe ou sem caminho)");
            return State.RUNNING;
        }
    }

    public static class ComeToMe extends Task {
        @Override
        public String describe() {
            return "ir ate o jogador";
        }

        @Override
        public State tick(CompanionEntity c) {
            ServerPlayer o = c.getOwner();
            if (o == null) return fail("o jogador nao esta online");
            if (moveToward(c, o.getX(), o.getY(), o.getZ(), 2.5D)) return done("cheguei perto do jogador");
            if (age > 20 * 90) return fail("nao consegui chegar ate o jogador");
            return State.RUNNING;
        }
    }

    /** Segue o jogador ate receber outra ordem. Nunca termina sozinha. */
    public static class Follow extends Task {
        @Override
        public String describe() {
            return "seguir o jogador";
        }

        @Override
        public State tick(CompanionEntity c) {
            ServerPlayer o = c.getOwner();
            if (o == null) return State.RUNNING;
            double d2 = c.distanceToSqr(o);
            if (d2 > 36.0D * 36.0D && Config.ALLOW_TELEPORT_UNSTUCK.get()) {
                teleportNear(c, o.getX(), o.getY(), o.getZ());
            } else if (d2 > 4.0D * 4.0D) {
                if (c.getNavigation().isDone() || age % 15 == 0) {
                    c.getNavigation().moveTo(o, 1.2D);
                }
            } else {
                c.getNavigation().stop();
            }
            return State.RUNNING;
        }
    }
}
