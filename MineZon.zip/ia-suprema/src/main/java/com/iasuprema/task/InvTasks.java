package com.iasuprema.task;

import com.iasuprema.Names;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.SimpleContainer;

import java.util.List;
import java.util.stream.Collectors;

/** Tarefas de inventario: craftar, entregar itens, vestir armadura. */
public final class InvTasks {
    private InvTasks() {}

    public static class Craft extends Task {
        private final String spec;
        private final int count;

        public Craft(String spec, int count) {
            this.spec = spec == null ? "" : spec;
            this.count = Math.max(1, Math.min(count, 512));
        }

        @Override
        public String describe() {
            return "craftar " + count + "x " + spec;
        }

        @Override
        public State tick(CompanionEntity c) {
            Item target = Names.item(spec);
            if (target == null) return fail("item desconhecido: '" + spec + "'");

            List<CraftingRecipe> recipes = c.level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING).stream()
                    .filter(r -> r.getResultItem().is(target))
                    .collect(Collectors.toList());
            if (recipes.isEmpty()) return fail("nao existe receita de craft para " + spec + " (talvez precise fundir/outra estacao)");

            for (CraftingRecipe r : recipes) {
                int perCraft = Math.max(1, r.getResultItem().getCount());
                int crafts = (int) Math.ceil(count / (double) perCraft);
                int done = 0;
                for (int k = 0; k < crafts; k++) {
                    if (!consume(c.inventory, r)) break;
                    c.give(r.getResultItem().copy());
                    done++;
                }
                if (done > 0) {
                    int total = done * perCraft;
                    return done("fiz " + total + "x " + Names.id(target)
                            + (total < count ? " (faltaram ingredientes para o resto)" : ""));
                }
            }
            String need = recipes.get(0).getIngredients().stream()
                    .filter(i -> !i.isEmpty())
                    .map(i -> i.getItems().length > 0 ? Names.id(i.getItems()[0].getItem()) : "?")
                    .collect(Collectors.joining(", "));
            return fail("faltam ingredientes para " + spec + ". Receita precisa de (1 de cada): " + need);
        }

        private static boolean consume(SimpleContainer inv, CraftingRecipe r) {
            int size = inv.getContainerSize();
            int[] used = new int[size];
            for (Ingredient ing : r.getIngredients()) {
                if (ing.isEmpty()) continue;
                boolean found = false;
                for (int i = 0; i < size; i++) {
                    ItemStack s = inv.getItem(i);
                    if (!s.isEmpty() && used[i] < s.getCount() && ing.test(s)) {
                        used[i]++;
                        found = true;
                        break;
                    }
                }
                if (!found) return false;
            }
            for (int i = 0; i < size; i++) {
                if (used[i] > 0) inv.removeItem(i, used[i]);
            }
            return true;
        }
    }

    public static class GiveToPlayer extends Task {
        private final String spec;
        private final int count; // -1 = tudo que combinar

        public GiveToPlayer(String spec, int count) {
            this.spec = spec == null ? "" : spec;
            this.count = count;
        }

        @Override
        public String describe() {
            return "entregar " + (count < 0 ? "tudo" : count + "x") + " " + spec;
        }

        @Override
        public State tick(CompanionEntity c) {
            ServerPlayer o = c.getOwner();
            if (o == null) return fail("o jogador nao esta online");
            if (!moveToward(c, o.getX(), o.getY(), o.getZ(), 2.5D)) {
                if (age > 20 * 90) return fail("nao consegui chegar ate o jogador");
                return State.RUNNING;
            }
            int remaining = count < 0 ? Integer.MAX_VALUE : count;
            int given = 0;
            for (int i = 0; i < c.inventory.getContainerSize() && remaining > 0; i++) {
                ItemStack s = c.inventory.getItem(i);
                if (s.isEmpty() || !Names.matches(Names.id(s.getItem()), spec)) continue;
                int take = Math.min(remaining, s.getCount());
                ItemStack part = s.split(take);
                given += part.getCount();
                remaining -= part.getCount();
                if (!o.getInventory().add(part) && !part.isEmpty()) o.drop(part, false);
            }
            if (given == 0) return fail("nao tenho '" + spec + "' no inventario");
            return done("entreguei " + given + "x " + spec + " ao jogador");
        }
    }

    public static class EquipBest extends Task {
        @Override
        public String describe() {
            return "vestir a melhor armadura";
        }

        @Override
        public State tick(CompanionEntity c) {
            int n = c.equipBestArmor();
            return done("troquei " + n + " peca(s) de armadura");
        }
    }
}
