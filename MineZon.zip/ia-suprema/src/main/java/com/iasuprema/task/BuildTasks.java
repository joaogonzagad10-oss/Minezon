package com.iasuprema.task;

import com.iasuprema.Config;
import com.iasuprema.Names;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Construcao: preenche uma regiao (como o /fill) andando e gastando materiais do inventario. */
public final class BuildTasks {
    private BuildTasks() {}

    public static class Fill extends Task {
        private final String blockSpec;
        private final int minX, minY, minZ, maxX, maxY, maxZ;
        private final String mode;
        private final boolean replace;

        private String error = null;
        private Block block;
        private BlockState state;
        private Item item;
        private boolean clear;
        private List<BlockPos> todo;
        private int index = 0, placed = 0, skipped = 0;

        public Fill(String blockSpec, int x1, int y1, int z1, int x2, int y2, int z2, String mode, boolean replace) {
            this.blockSpec = blockSpec == null ? "" : blockSpec;
            this.minX = Math.min(x1, x2);
            this.maxX = Math.max(x1, x2);
            this.minY = Math.min(y1, y2);
            this.maxY = Math.max(y1, y2);
            this.minZ = Math.min(z1, z2);
            this.maxZ = Math.max(z1, z2);
            this.mode = mode == null ? "solid" : mode.toLowerCase(Locale.ROOT);
            this.replace = replace;
        }

        @Override
        public String describe() {
            return (clear ? "limpar" : "construir " + blockSpec) + " [" + mode + "] de "
                    + minX + " " + minY + " " + minZ + " ate " + maxX + " " + maxY + " " + maxZ;
        }

        @Override
        public void start(CompanionEntity c) {
            state = Names.state(blockSpec);
            if (state == null) {
                error = "bloco desconhecido ou estado invalido: '" + blockSpec
                        + "' (use ids como minecraft:oak_planks ou minecraft:oak_stairs[facing=north,half=bottom])";
                return;
            }
            block = state.getBlock();
            clear = block == Blocks.AIR;
            item = block.asItem();
            if (!clear && item == Items.AIR && !Config.CREATIVE_MODE.get()) {
                error = "nao da pra obter esse bloco como item: " + blockSpec;
                return;
            }
            long volume = (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
            if (volume > Config.MAX_BLOCKS_PER_FILL.get()) {
                error = "area grande demais (" + volume + " blocos; limite " + Config.MAX_BLOCKS_PER_FILL.get() + "). Divida em partes.";
                return;
            }
            if (minY < c.level.getMinBuildHeight() || maxY >= c.level.getMaxBuildHeight()) {
                error = "altura fora do limite do mundo (" + c.level.getMinBuildHeight() + " a " + (c.level.getMaxBuildHeight() - 1) + ")";
                return;
            }
            todo = new ArrayList<>();
            for (int y = minY; y <= maxY; y++) {
                for (int x = minX; x <= maxX; x++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        boolean edgeXZ = x == minX || x == maxX || z == minZ || z == maxZ;
                        boolean edgeY = y == minY || y == maxY;
                        boolean take = switch (mode) {
                            case "hollow" -> edgeXZ || edgeY;
                            case "walls" -> edgeXZ;
                            default -> true;
                        };
                        if (take) todo.add(new BlockPos(x, y, z));
                    }
                }
            }
        }

        @Override
        public State tick(CompanionEntity c) {
            if (error != null) return fail(error);
            if (!(c.level instanceof ServerLevel level)) return fail("sem mundo");
            if (age > 20 * 60 * 6) return fail("demorei demais; fiz " + placed + " de " + todo.size());

            int budget = 2;
            while (budget > 0 && index < todo.size()) {
                BlockPos p = todo.get(index);
                BlockState cur = level.getBlockState(p);

                if (cur.getDestroySpeed(level, p) < 0.0F && !cur.isAir()) { // inquebravel
                    skipped++;
                    index++;
                    continue;
                }
                if (clear) {
                    if (cur.isAir()) {
                        index++;
                        continue;
                    }
                } else {
                    if (cur == state) {
                        index++;
                        continue;
                    }
                    if (!replace && !cur.isAir() && !cur.getMaterial().isReplaceable()) {
                        skipped++;
                        index++;
                        continue;
                    }
                }

                if (!moveToward(c, p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D, 4.5D)) return State.RUNNING;
                c.getLookControl().setLookAt(p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D);

                if (clear) {
                    List<ItemStack> drops = Block.getDrops(cur, level, p, level.getBlockEntity(p), c, ItemStack.EMPTY);
                    level.destroyBlock(p, false, c);
                    for (ItemStack d : drops) c.give(d);
                    placed++;
                } else {
                    AABB box = new AABB(p);
                    if (c.getBoundingBox().intersects(box) && !stepAside(c, level, p)) {
                        skipped++;
                        index++;
                        continue;
                    }
                    ServerPlayer o = c.getOwner();
                    if (o != null && o.getBoundingBox().intersects(box)) {
                        skipped++; // nao enterra o jogador
                        index++;
                        continue;
                    }
                    if (!Config.CREATIVE_MODE.get()) {
                        ItemStack taken = c.inventory.removeItemType(item, 1);
                        if (taken.isEmpty()) {
                            return fail("faltou material: " + Names.id(item) + " (coloquei " + placed + " de " + todo.size()
                                    + "). Consiga mais e peca de novo.");
                        }
                    }
                    level.setBlock(p, state, 3);
                    level.playSound(null, p, state.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
                    placed++;
                }
                c.swing(InteractionHand.MAIN_HAND);
                index++;
                budget--;
            }

            if (index >= todo.size()) {
                return done((clear ? "limpei " : "coloquei ") + placed + " bloco(s)"
                        + (skipped > 0 ? " (" + skipped + " pulados por estarem ocupados/inquebraveis)" : ""));
            }
            return State.RUNNING;
        }

        /** Sobe o companheiro pra cima do bloco que vai ser colocado, se houver espaco. */
        private boolean stepAside(CompanionEntity c, ServerLevel level, BlockPos p) {
            BlockPos up1 = p.above();
            BlockPos up2 = p.above(2);
            if (level.getBlockState(up1).getCollisionShape(level, up1).isEmpty()
                    && level.getBlockState(up2).getCollisionShape(level, up2).isEmpty()) {
                c.teleportTo(p.getX() + 0.5D, p.getY() + 1.0D, p.getZ() + 0.5D);
                return true;
            }
            return false;
        }
    }
}
