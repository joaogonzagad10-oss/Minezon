package com.iasuprema.task;

import com.iasuprema.Config;
import com.iasuprema.Names;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

import java.util.List;

public final class CombatTasks {
    private CombatTasks() {}

    public static class Attack extends Task {
        private final String spec; // "hostile" (padrao) ou parte do id do mob, ex.: "cow", "zombie"
        private final int count;
        private int kills = 0;
        private int cooldown = 0;
        private LivingEntity target = null;

        public Attack(String spec, int count) {
            this.spec = (spec == null || spec.isBlank()) ? "hostile" : spec;
            this.count = Math.max(1, Math.min(count, 64));
        }

        @Override
        public String describe() {
            return "atacar " + count + "x " + spec;
        }

        @Override
        public void cancel(CompanionEntity c) {
            c.setTarget(null);
        }

        @Override
        public State tick(CompanionEntity c) {
            if (age > 20 * 150) return kills > 0 ? done("derrotei " + kills) : fail("demorei demais");
            if (c.getHealth() < c.getMaxHealth() * 0.25F) {
                return fail("vida baixa (" + (int) c.getHealth() + "), parei de lutar. Derrotei " + kills);
            }

            if (target != null && !target.isAlive()) {
                kills++;
                target = null;
                c.setTarget(null);
            }
            if (kills >= count) return done("derrotei " + kills + " alvo(s) de '" + spec + "'");

            if (target == null) {
                target = findTarget(c);
                if (target == null) {
                    return kills > 0
                            ? done("derrotei " + kills + " (nao ha mais '" + spec + "' por perto)")
                            : fail("nao ha alvo '" + spec + "' por perto");
                }
                c.equipBestWeapon();
                c.setTarget(target);
            }

            double reach = 2.0D + target.getBbWidth() * 0.5D;
            if (c.distanceTo(target) > reach) {
                if (c.getNavigation().isDone() || age % 10 == 0) c.getNavigation().moveTo(target, 1.25D);
            } else {
                c.getNavigation().stop();
                c.getLookControl().setLookAt(target, 30.0F, 30.0F);
                if (cooldown <= 0) {
                    c.swing(InteractionHand.MAIN_HAND);
                    c.doHurtTarget(target);
                    cooldown = 12;
                }
            }
            if (cooldown > 0) cooldown--;
            return State.RUNNING;
        }

        private LivingEntity findTarget(CompanionEntity c) {
            double radius = Config.SEARCH_RADIUS.get();
            List<LivingEntity> list = c.level.getEntitiesOfClass(LivingEntity.class, c.getBoundingBox().inflate(radius), e ->
                    e != c && e.isAlive()
                            && !(e instanceof Player)
                            && !(e instanceof CompanionEntity)
                            && !(e instanceof TamableAnimal t && t.isTame())
                            && matches(e));
            LivingEntity best = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity e : list) {
                double d = c.distanceToSqr(e);
                if (d < bd) {
                    bd = d;
                    best = e;
                }
            }
            return best;
        }

        private boolean matches(LivingEntity e) {
            if (spec.equalsIgnoreCase("hostile")) return e instanceof Enemy;
            return Names.matches(Names.id(e.getType()), spec);
        }
    }
}
