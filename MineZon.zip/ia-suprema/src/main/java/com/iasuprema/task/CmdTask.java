package com.iasuprema.task;

import com.iasuprema.Config;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;

import java.util.Locale;
import java.util.Set;

/** Executa um comando do Minecraft com as permissoes do proprio jogador (so funciona se ele puder usar o comando). */
public class CmdTask extends Task {
    private static final Set<String> BLOCKED = Set.of(
            "stop", "op", "deop", "ban", "ban-ip", "banlist", "pardon", "pardon-ip", "kick", "whitelist",
            "publish", "debug", "perf", "setidletimeout", "save-all", "save-on", "save-off", "reload", "ia");

    private final String command;
    private final boolean confirmed;

    public CmdTask(String command, boolean confirmed) {
        String c = command == null ? "" : command.trim();
        this.command = c.startsWith("/") ? c.substring(1) : c;
        this.confirmed = confirmed;
    }

    @Override
    public String describe() {
        return "comando /" + command;
    }

    @Override
    public State tick(CompanionEntity c) {
        if (!Config.ALLOW_COMMANDS.get()) return fail("comandos estao desativados no config (allowCommands)");
        if (command.isEmpty()) return fail("comando vazio");
        String root = command.split("\\s+")[0].toLowerCase(Locale.ROOT);
        if (root.contains(":")) root = root.substring(root.indexOf(':') + 1);
        if (BLOCKED.contains(root)) return fail("o comando /" + root + " e bloqueado por seguranca");

        ServerPlayer owner = c.getOwner();
        if (owner == null) return fail("o jogador nao esta online");

        // Modo survival: trapacear tira a graca, entao o jogador precisa ter confirmado explicitamente.
        boolean survival = !owner.isCreative() && !owner.isSpectator();
        if (survival && !confirmed) {
            return fail("o jogador esta no SURVIVAL e ainda nao confirmou. PERGUNTE antes (\"tem certeza? isso pode tirar a graca do jogo\") "
                    + "e so repita o comando com confirmed=true depois que ele disser que sim");
        }

        // No singleplayer funciona mesmo sem ser OP. Em servidor multiplayer exige OP (a menos que o config libere).
        boolean allowed = owner.hasPermissions(2)
                || c.getServer().isSingleplayer()
                || Config.COMMANDS_BYPASS_OP_ON_SERVERS.get();
        if (!allowed) return fail("servidor multiplayer: o jogador precisa ser operador para usar comandos");

        CommandSourceStack src = owner.createCommandSourceStack().withPermission(4);
        int r;
        try {
            r = c.getServer().getCommands().performCommand(src, command);
        } catch (Exception e) {
            return fail("erro ao executar: " + e.getMessage());
        }
        return r > 0 ? done("executei /" + command) : fail("o comando /" + command + " nao funcionou (sintaxe errada ou sem efeito)");
    }
}
