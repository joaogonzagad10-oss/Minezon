package com.iasuprema.task;

import com.iasuprema.Config;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Uma acao que o companheiro executa, tick a tick, no thread do servidor. */
public abstract class Task {
    public enum State { RUNNING, DONE, FAILED }

    /** Texto de resultado devolvido para a IA quando a tarefa termina. */
    public String result = "";
    public int age = 0;

    private Vec3 lastPos = null;
    private int stuckTicks = 0;

    public abstract String describe();

    public void start(CompanionEntity c) {}

    public abstract State tick(CompanionEntity c);

    /** Chamado quando a tarefa e cancelada no meio. */
    public void cancel(CompanionEntity c) {}

    protected State fail(String why) {
        result = "FALHOU: " + why;
        return State.FAILED;
    }

    protected State done(String what) {
        result = "OK: " + what;
        return State.DONE;
    }

    /** Anda ate o ponto. Retorna true quando esta a "reach" blocos dele. */
    protected boolean moveToward(CompanionEntity c, double x, double y, double z, double reach) {
        if (c.distanceToSqr(x, y, z) <= reach * reach) {
            c.getNavigation().stop();
            return true;
        }
        if (c.getNavigation().isDone() || age % 20 == 0) {
            c.getNavigation().moveTo(x, y, z, 1.15D);
        }
        if (age % 20 == 0) {
            Vec3 now = c.position();
            if (lastPos != null && now.distanceToSqr(lastPos) < 0.04D) stuckTicks += 20;
            else stuckTicks = 0;
            lastPos = now;
        }
        if (stuckTicks >= 100) {
            stuckTicks = 0;
            if (Config.ALLOW_TELEPORT_UNSTUCK.get()) teleportNear(c, x, y, z);
        }
        return false;
    }

    /** Teletransporta o companheiro para um lugar seguro perto do ponto. */
    protected boolean teleportNear(CompanionEntity c, double x, double y, double z) {
        Level level = c.level;
        BlockPos center = new BlockPos(x, y, z);
        for (int r = 1; r <= 3; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    for (int dy = 2; dy >= -2; dy--) {
                        BlockPos p = center.offset(dx, dy, dz);
                        if (isStandable(level, p)) {
                            c.teleportTo(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D);
                            c.getNavigation().stop();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    protected static boolean isStandable(Level level, BlockPos p) {
        return level.getBlockState(p).getCollisionShape(level, p).isEmpty()
                && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()
                && !level.getBlockState(p.below()).getCollisionShape(level, p.below()).isEmpty()
                && level.getFluidState(p).isEmpty();
    }
}
