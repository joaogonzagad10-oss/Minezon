package com.iasuprema.task;

import com.iasuprema.Config;
import com.iasuprema.Names;
import com.iasuprema.entity.CompanionEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Minerar blocos e coletar itens do chao. */
public final class MineTasks {
    private MineTasks() {}

    public static class Mine extends Task {
        private final String spec;
        private final int count;
        private final int radius = Config.SEARCH_RADIUS.get();
        private final Set<BlockPos> bad = new HashSet<>();
        private int mined = 0;
        private BlockPos target = null;
        private float progress = 0.0F;
        private int targetAge = 0;

        public Mine(String spec, int count) {
            this.spec = spec == null ? "" : spec;
            this.count = Math.max(1, Math.min(count, 512));
        }

        @Override
        public String describe() {
            return "minerar " + count + "x " + spec;
        }

        @Override
        public void cancel(CompanionEntity c) {
            if (target != null) c.level.destroyBlockProgress(c.getId(), target, -1);
        }

        @Override
        public State tick(CompanionEntity c) {
            if (!(c.level instanceof ServerLevel level)) return fail("sem mundo");
            if (mined >= count) return done("minerei " + mined + " bloco(s) de " + spec);

            if (target == null) {
                target = findNearest(c, level);
                progress = 0.0F;
                targetAge = 0;
                if (target == null) {
                    return mined > 0
                            ? done("minerei " + mined + " (nao achei mais '" + spec + "' no raio de " + radius + ")")
                            : fail("nao encontrei '" + spec + "' num raio de " + radius + " blocos");
                }
            }

            BlockState st = level.getBlockState(target);
            if (st.isAir() || !Names.matches(Names.id(st.getBlock()), spec)) {
                target = null; // sumiu ou mudou
                return State.RUNNING;
            }

            targetAge++;
            if (targetAge > 20 * 45) { // nao consegui chegar a tempo
                level.destroyBlockProgress(c.getId(), target, -1);
                bad.add(target);
                target = null;
                return State.RUNNING;
            }

            double cx = target.getX() + 0.5D, cy = target.getY() + 0.5D, cz = target.getZ() + 0.5D;
            if (!moveToward(c, cx, cy, cz, 4.0D)) return State.RUNNING;

            c.getLookControl().setLookAt(cx, cy, cz);
            float hardness = st.getDestroySpeed(level, target);
            if (hardness < 0.0F) { // inquebravel
                bad.add(target);
                target = null;
                return State.RUNNING;
            }

            ItemStack tool = c.equipBestTool(st);
            boolean correct = !st.requiresCorrectToolForDrops() || tool.isCorrectToolForDrops(st);
            float speed = tool.isEmpty() ? 1.0F : tool.getDestroySpeed(st);
            progress += hardness == 0.0F ? 1.0F : speed / hardness / (correct ? 30.0F : 100.0F);
            if (age % 6 == 0) c.swing(InteractionHand.MAIN_HAND);
            level.destroyBlockProgress(c.getId(), target, Math.min(9, (int) (progress * 10.0F)));

            if (progress >= 1.0F) {
                List<ItemStack> drops = Block.getDrops(st, level, target, level.getBlockEntity(target), c, tool);
                level.destroyBlockProgress(c.getId(), target, -1);
                level.destroyBlock(target, false, c);
                for (ItemStack d : drops) c.give(d);
                if (!tool.isEmpty()) {
                    tool.hurtAndBreak(1, c, e -> e.broadcastBreakEvent(InteractionHand.MAIN_HAND));
                }
                mined++;
                target = null;
                progress = 0.0F;
            }
            return State.RUNNING;
        }

        private BlockPos findNearest(CompanionEntity c, ServerLevel level) {
            BlockPos base = c.blockPosition();
            int vr = Math.min(radius, 16);
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            for (BlockPos q : BlockPos.betweenClosed(base.offset(-radius, -vr, -radius), base.offset(radius, vr, radius))) {
                BlockState st = level.getBlockState(q);
                if (st.isAir()) continue;
                if (bad.contains(q)) continue;
                if (!Names.matches(Names.id(st.getBlock()), spec)) continue;
                double d = q.distSqr(base);
                if (d < bestD) {
                    bestD = d;
                    best = q.immutable();
                }
            }
            return best;
        }
    }

    public static class Collect extends Task {
        private final String spec;
        private final int radius = Config.SEARCH_RADIUS.get();
        private int collected = 0;
        private ItemEntity target = null;

        public Collect(String spec) {
            this.spec = spec == null ? "" : spec;
        }

        @Override
        public String describe() {
            return "coletar itens" + (spec.isBlank() ? "" : " (" + spec + ")");
        }

        @Override
        public State tick(CompanionEntity c) {
            if (age > 20 * 90) return collected > 0 ? done("coletei " + collected + " item(ns)") : fail("demorei demais");

            if (target == null || !target.isAlive()) {
                target = null;
                double best = Double.MAX_VALUE;
                for (ItemEntity ie : c.level.getEntitiesOfClass(ItemEntity.class, c.getBoundingBox().inflate(radius))) {
                    if (!ie.isAlive()) continue;
                    if (!Names.matches(Names.id(ie.getItem().getItem()), spec)) continue;
                    double d = c.distanceToSqr(ie);
                    if (d < best) {
                        best = d;
                        target = ie;
                    }
                }
                if (target == null) {
                    return collected > 0
                            ? done("coletei " + collected + " item(ns)")
                            : fail("nao ha itens" + (spec.isBlank() ? "" : " '" + spec + "'") + " no chao por perto");
                }
            }

            if (moveToward(c, target.getX(), target.getY(), target.getZ(), 1.4D)) {
                ItemStack s = target.getItem().copy();
                collected += s.getCount();
                c.give(s);
                target.discard();
                target = null;
            }
            return State.RUNNING;
        }
    }
}
