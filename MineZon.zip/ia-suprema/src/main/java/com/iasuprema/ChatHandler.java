package com.iasuprema;

import com.iasuprema.ai.AiBrain;
import com.iasuprema.entity.CompanionEntity;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.Util;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Locale;

public class ChatHandler {

    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String msg = event.getMessage().trim();
        String prefix = Config.PREFIX.get().trim().toLowerCase(Locale.ROOT);
        if (prefix.isEmpty()) return;

        String low = msg.toLowerCase(Locale.ROOT);
        String rest = null;
        if (low.startsWith(prefix)) {
            String r = msg.substring(prefix.length());
            if (r.isEmpty() || !Character.isLetterOrDigit(r.charAt(0))) { // evita "iatrio"
                r = r.replaceFirst("^[\\s,:;\\-]+", "").trim();
                if (!r.isEmpty()) rest = r;
            }
        }

        if (rest == null) {
            // Sem prefixo: so vale como resposta se a IA falou ha pouco tempo.
            int follow = Config.FOLLOWUP_SECONDS.get();
            if (follow <= 0 || msg.isEmpty()) return;
            final String reply = msg;
            player.getServer().execute(() -> {
                CompanionEntity c = AiBrain.find(player.getServer(), player.getUUID());
                if (c == null || c.thinking) return;
                if (c.level.getGameTime() - c.lastSayTime > follow * 20L) return;
                AiBrain.onPlayerMessage(c, reply);
            });
            return;
        }

        final String order = rest;
        player.getServer().execute(() -> {
            CompanionEntity c = AiBrain.find(player.getServer(), player.getUUID());
            if (c == null) {
                player.sendMessage(new TextComponent("<Supremo> Voce ainda nao tem um companheiro. "
                        + "Use o Ovo de Criacao: Companheiro IA ou o comando /ia spawn."), Util.NIL_UUID);
                return;
            }
            AiBrain.onPlayerMessage(c, order);
        });
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ia")
                .then(Commands.literal("spawn").executes(ctx -> spawn(ctx.getSource())))
                .then(Commands.literal("parar").executes(ctx -> stop(ctx.getSource())))
                .then(Commands.literal("inventario").executes(ctx -> inv(ctx.getSource())))
                .then(Commands.literal("fala").then(Commands.argument("texto", StringArgumentType.greedyString())
                        .executes(ctx -> talk(ctx.getSource(), StringArgumentType.getString(ctx, "texto")))))
        );
    }

    private int spawn(CommandSourceStack src) {
        try {
            ServerPlayer p = src.getPlayerOrException();
            CompanionEntity old = AiBrain.find(src.getServer(), p.getUUID());
            if (old != null) {
                old.teleportTo(p.getX(), p.getY(), p.getZ());
                src.sendSuccess(new TextComponent("Seu companheiro veio ate voce."), false);
                return 1;
            }
            CompanionEntity c = IaSuprema.COMPANION.get().create(p.getLevel());
            if (c == null) return 0;
            c.moveTo(p.getX() + 1.0D, p.getY(), p.getZ(), 0.0F, 0.0F);
            c.setOwnerId(p.getUUID());
            p.getLevel().addFreshEntity(c);
            src.sendSuccess(new TextComponent("Companheiro criado! Fale no chat comecando com \"" + Config.PREFIX.get() + "\"."), false);
            return 1;
        } catch (Exception e) {
            src.sendFailure(new TextComponent("Só jogadores podem usar isso."));
            return 0;
        }
    }

    private int stop(CommandSourceStack src) {
        try {
            ServerPlayer p = src.getPlayerOrException();
            CompanionEntity c = AiBrain.find(src.getServer(), p.getUUID());
            if (c == null) {
                src.sendFailure(new TextComponent("Voce nao tem companheiro."));
                return 0;
            }
            c.goalActive = false;
            c.report.clear();
            c.clearTasks();
            src.sendSuccess(new TextComponent("Companheiro parou."), false);
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    private int inv(CommandSourceStack src) {
        try {
            ServerPlayer p = src.getPlayerOrException();
            CompanionEntity c = AiBrain.find(src.getServer(), p.getUUID());
            if (c == null) {
                src.sendFailure(new TextComponent("Voce nao tem companheiro."));
                return 0;
            }
            src.sendSuccess(new TextComponent("Inventario: " + c.inventorySummary()), false);
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    private int talk(CommandSourceStack src, String text) {
        try {
            ServerPlayer p = src.getPlayerOrException();
            CompanionEntity c = AiBrain.find(src.getServer(), p.getUUID());
            if (c == null) {
                src.sendFailure(new TextComponent("Voce nao tem companheiro."));
                return 0;
            }
            AiBrain.onPlayerMessage(c, text);
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }
}
