package com.iasuprema.entity;

import com.iasuprema.Config;
import com.iasuprema.Names;
import com.iasuprema.ai.AiBrain;
import com.iasuprema.task.Task;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CompanionEntity extends PathfinderMob {
    public static final String NAME = "Supremo";

    public final SimpleContainer inventory = new SimpleContainer(36);
    public final Deque<Task> queue = new ArrayDeque<>();
    public Task current = null;

    /** Resultados das tarefas desde o ultimo plano, para a IA. */
    public final List<String> report = new ArrayList<>();
    /** Historico curto da conversa (texto) para dar contexto a IA. */
    public final Deque<String> history = new ArrayDeque<>();

    private UUID ownerId = null;
    public boolean goalActive = false;
    public boolean thinking = false;
    public int replans = 0;
    public String goal = "";

    public CompanionEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setCustomName(new TextComponent(NAME));
        this.setCustomNameVisible(true);
        this.setPersistenceRequired();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setDropChance(slot, 0.0F);
        }
        if (this.getNavigation() instanceof GroundPathNavigation g) {
            g.setCanFloat(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    // ---------------------------------------------------------------- dono

    public UUID getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(UUID id) {
        this.ownerId = id;
    }

    public ServerPlayer getOwner() {
        if (ownerId == null || !(level instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(ownerId);
    }

    public long lastSayTime = -1000000L;

    public void say(String msg) {
        lastSayTime = level.getGameTime();
        ServerPlayer o = getOwner();
        if (o != null) {
            o.sendMessage(new TextComponent("<" + NAME + "> " + msg), Util.NIL_UUID);
        }
    }

    // ---------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        if (level.isClientSide) return;

        if (ownerId == null && tickCount == 10) {
            Player p = level.getNearestPlayer(this, 12.0D);
            if (p != null) ownerId = p.getUUID();
        }
        if (ownerId != null && tickCount % 40 == 0) {
            AiBrain.register(ownerId, getUUID());
        }
        runTasks();
    }

    private void runTasks() {
        if (current == null) {
            current = queue.poll();
            if (current != null) {
                try {
                    current.start(this);
                } catch (Exception e) {
                    finishCurrent(Task.State.FAILED, "erro interno: " + e);
                    return;
                }
            }
        }
        if (current == null) return;

        Task.State s;
        try {
            s = current.tick(this);
            current.age++;
        } catch (Exception e) {
            current.result = "FALHOU: erro interno: " + e;
            s = Task.State.FAILED;
        }
        if (s != Task.State.RUNNING) {
            finishCurrent(s, null);
        }
    }

    private void finishCurrent(Task.State s, String forcedResult) {
        Task t = current;
        current = null;
        if (t == null) return;
        if (forcedResult != null) t.result = "FALHOU: " + forcedResult;
        report.add(t.describe() + " -> " + t.result);
        if (s == Task.State.FAILED) {
            queue.clear();
            this.getNavigation().stop();
            AiBrain.onIdle(this, true);
        } else if (queue.isEmpty()) {
            AiBrain.onIdle(this, false);
        }
    }

    public void clearTasks() {
        if (current != null) {
            try {
                current.cancel(this);
            } catch (Exception ignored) {
            }
            current = null;
        }
        queue.clear();
        getNavigation().stop();
        setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }

    public void setPlan(List<Task> tasks) {
        clearTasks();
        queue.addAll(tasks);
    }

    // ---------------------------------------------------------------- inventario

    public void give(ItemStack s) {
        if (s.isEmpty()) return;
        ItemStack rest = inventory.addItem(s);
        if (!rest.isEmpty()) spawnAtLocation(rest);
    }

    public int countItem(Item item) {
        int n = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public ItemStack equipBestTool(BlockState st) {
        ItemStack best = ItemStack.EMPTY;
        float bestScore = 1.0F;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            float sc = s.getDestroySpeed(st);
            if (sc <= 1.0F) continue;
            if (s.isCorrectToolForDrops(st)) sc += 1000.0F;
            if (sc > bestScore) {
                best = s;
                bestScore = sc;
            }
        }
        setItemSlot(EquipmentSlot.MAINHAND, best);
        return best;
    }

    public void equipBestWeapon() {
        ItemStack best = ItemStack.EMPTY;
        double bestDmg = 0.0D;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            double d = 0.0D;
            for (AttributeModifier m : s.getAttributeModifiers(EquipmentSlot.MAINHAND).get(Attributes.ATTACK_DAMAGE)) {
                d += m.getAmount();
            }
            if (d > bestDmg) {
                best = s;
                bestDmg = d;
            }
        }
        setItemSlot(EquipmentSlot.MAINHAND, best);
    }

    /** Veste a melhor armadura do inventario. Retorna quantas pecas trocou. */
    public int equipBestArmor() {
        int changed = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty() || !(s.getItem() instanceof ArmorItem armor)) continue;
            EquipmentSlot slot = armor.getSlot();
            ItemStack worn = getItemBySlot(slot);
            int wornDef = worn.getItem() instanceof ArmorItem w ? w.getDefense() : -1;
            if (armor.getDefense() > wornDef) {
                ItemStack old = worn.copy();
                setItemSlot(slot, s.copy());
                inventory.setItem(i, old);
                changed++;
            }
        }
        return changed;
    }

    // ---------------------------------------------------------------- interacao

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (ownerId != null && !player.getUUID().equals(ownerId)) return InteractionResult.PASS;
        if (ownerId == null) ownerId = player.getUUID();

        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty()) {
            give(held.copy());
            player.sendMessage(new TextComponent("<" + NAME + "> Recebi " + held.getCount() + "x "
                    + Names.id(held.getItem()) + "."), Util.NIL_UUID);
            held.shrink(held.getCount());
        } else if (player.isShiftKeyDown()) {
            for (int i = 0; i < inventory.getContainerSize(); i++) {
                ItemStack s = inventory.getItem(i);
                if (s.isEmpty()) continue;
                if (!player.getInventory().add(s)) player.drop(s, false);
            }
            inventory.clearContent();
            player.sendMessage(new TextComponent("<" + NAME + "> Devolvi tudo que eu carregava."), Util.NIL_UUID);
        } else {
            player.sendMessage(new TextComponent("<" + NAME + "> Carrego: " + inventorySummary()), Util.NIL_UUID);
        }
        return InteractionResult.CONSUME;
    }

    public String inventorySummary() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            m.merge(Names.id(s.getItem()), s.getCount(), Integer::sum);
        }
        if (m.isEmpty()) return "(vazio)";
        StringBuilder sb = new StringBuilder();
        m.forEach((k, v) -> sb.append(v).append("x ").append(k).append(", "));
        sb.setLength(sb.length() - 2);
        return sb.toString();
    }

    // ---------------------------------------------------------------- contexto para a IA

    public String snapshot() {
        StringBuilder sb = new StringBuilder();
        BlockPos p = blockPosition();
        sb.append("Posicao do companheiro: ").append(p.getX()).append(' ').append(p.getY()).append(' ').append(p.getZ()).append('\n');
        ServerPlayer o = getOwner();
        if (o != null) {
            BlockPos op = o.blockPosition();
            sb.append("Posicao do jogador (dono): ").append(op.getX()).append(' ').append(op.getY()).append(' ').append(op.getZ()).append('\n');
            String mode = o.isCreative() ? "CRIATIVO" : o.isSpectator() ? "ESPECTADOR" : "SURVIVAL";
            sb.append("Modo de jogo do jogador: ").append(mode).append('\n');
            sb.append("Partida: ").append(level.getServer() != null && level.getServer().isSingleplayer() ? "singleplayer" : "multiplayer").append('\n');
        }
        sb.append("Vida: ").append((int) getHealth()).append('/').append((int) getMaxHealth()).append('\n');
        sb.append("Dimensao: ").append(level.dimension().location()).append('\n');
        sb.append("Hora do dia (0-24000, noite apos ~13000): ").append(level.getDayTime() % 24000L).append('\n');
        sb.append("Inventario: ").append(inventorySummary()).append('\n');
        if (current != null || !queue.isEmpty()) {
            sb.append("Tarefas em andamento: ");
            if (current != null) sb.append("[agora] ").append(current.describe()).append("; ");
            for (Task t : queue) sb.append(t.describe()).append("; ");
            sb.append("(se voce mandar novas acoes, elas SUBSTITUEM estas; se quiser manter, inclua-as de novo)\n");
        }

        Map<String, Integer> blocks = new LinkedHashMap<>();
        for (BlockPos q : BlockPos.betweenClosed(p.offset(-8, -5, -8), p.offset(8, 6, 8))) {
            BlockState st = level.getBlockState(q);
            if (st.isAir()) continue;
            blocks.merge(Names.id(st.getBlock()), 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> es = new ArrayList<>(blocks.entrySet());
        es.sort((a, b) -> b.getValue() - a.getValue());
        sb.append("Blocos por perto (raio 8): ");
        int n = 0;
        for (Map.Entry<String, Integer> e : es) {
            if (n++ >= 40) break;
            sb.append(e.getKey()).append('=').append(e.getValue()).append(' ');
        }
        sb.append('\n');

        List<LivingEntity> living = level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(16.0D), e -> e != this);
        sb.append("Seres por perto (raio 16): ");
        int k = 0;
        for (LivingEntity e : living) {
            if (k++ >= 12) break;
            sb.append(Names.id(e.getType())).append(" a ").append((int) distanceTo(e)).append("m; ");
        }
        sb.append('\n');

        List<ItemEntity> items = level.getEntitiesOfClass(ItemEntity.class, getBoundingBox().inflate(16.0D));
        Map<String, Integer> drops = new LinkedHashMap<>();
        for (ItemEntity ie : items) drops.merge(Names.id(ie.getItem().getItem()), ie.getItem().getCount(), Integer::sum);
        sb.append("Itens no chao (raio 16): ").append(drops.isEmpty() ? "(nenhum)" : drops.toString()).append('\n');
        return sb.toString();
    }

    // ---------------------------------------------------------------- save / morte

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.remove("HandItems"); // o item da mao e a mesma referencia do inventario; nao duplicar
        if (ownerId != null) tag.putUUID("Owner", ownerId);
        tag.put("Inv", inventory.createTag());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) ownerId = tag.getUUID("Owner");
        inventory.fromTag(tag.getList("Inv", Tag.TAG_COMPOUND));
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource src, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(src, looting, recentlyHit);
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty()) spawnAtLocation(s.copy());
        }
        inventory.clearContent();
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack a = getItemBySlot(slot);
            if (!a.isEmpty()) spawnAtLocation(a.copy());
        }
    }
}
