# IA Suprema (Forge 1.18.2)

Um companheiro controlado por IA. Voce fala no chat e ele entende e executa:
andar, seguir, minerar, coletar, construir (fill), craftar, entregar itens, vestir armadura e lutar.

## Como usar
1. Compile pelo GitHub (Actions > build) e baixe o .jar em Artifacts. Coloque em `mods/`.
2. Abra o jogo uma vez para gerar `config/iasuprema-common.toml`, feche, e preencha:
   - `provider`: `anthropic` ou `openai` (qualquer API compativel com OpenAI)
   - `apiKey`: sua chave
   - `model`: nome do modelo
   - `baseUrl`: so se usar outro servico (ex.: Gemini: https://generativelanguage.googleapis.com/v1beta/openai)
3. No jogo: `/ia spawn` (ou use o Ovo de Criacao no modo criativo).
4. Fale no chat comecando com `ia`: `ia pega 20 madeira e constroi uma casinha aqui`.

## Comandos
- `/ia spawn` cria (ou traz) seu companheiro
- `/ia parar` cancela tudo
- `/ia inventario` mostra o que ele carrega
- `/ia fala <texto>` manda uma ordem sem usar o prefixo

Clique direito no companheiro com item na mao = entrega o item. Shift + clique vazio = ele devolve tudo.

## Como funciona
A ordem vai para a API junto com o contexto (posicao, inventario, blocos e seres por perto).
A IA responde um JSON com acoes; o mod executa tick a tick, junta o relatorio do que deu certo/errado
e devolve para a IA planejar o proximo passo (ate `maxReplans` vezes).
